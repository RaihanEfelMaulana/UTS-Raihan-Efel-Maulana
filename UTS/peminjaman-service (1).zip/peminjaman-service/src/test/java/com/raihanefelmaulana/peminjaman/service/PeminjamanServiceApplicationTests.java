package com.raihanefelmaulana.peminjaman.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeminjamanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
